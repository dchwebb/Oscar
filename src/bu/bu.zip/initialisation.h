void InitLCD(void)
{
	//	Enable GPIO and SPI clocks
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;			// reset and clock control - advanced high performance bus - GPIO port C
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;			// reset and clock control - advanced high performance bus - GPIO port D
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOFEN;			// reset and clock control - advanced high performance bus - GPIO port F
	RCC->APB2ENR |= RCC_APB2ENR_SPI5EN;

	// Init WRX pin PD13
	GPIOD->MODER |= GPIO_MODER_MODER13_0;			// 00: Input (reset state)	01: General purpose output mode	10: Alternate function mode	11: Analog mode
	GPIOD->OSPEEDR |= GPIO_OSPEEDER_OSPEEDR13_0;	// Medium  - 00: Low speed; 01: Medium speed; 10: High speed; 11: Very high speed

	// Init CS pin PC2
	GPIOC->MODER |= GPIO_MODER_MODER2_0;			// 00: Input (reset state)	01: General purpose output mode	10: Alternate function mode	11: Analog mode
	GPIOC->OSPEEDR |= GPIO_OSPEEDER_OSPEEDR2_0;		// Medium  - 00: Low speed; 01: Medium speed; 10: High speed; 11: Very high speed

	// Init RESET pin PD12
	GPIOD->MODER |= GPIO_MODER_MODER12_0;			// 00: Input (reset state)	01: General purpose output mode	10: Alternate function mode	11: Analog mode
	GPIOD->PUPDR |= GPIO_PUPDR_PUPDR12_0;			// Pull up - 00: No pull-up, pull-down; 01 Pull-up; 10 Pull-down; 11 Reserved

	// Setup SPI pins -  PF7: SPI5_SCK;  PF8: SPI5_MISO;  PF9: SPI5_MOSI [all alternate function AF5 for SPI5]
	GPIOF->MODER |= GPIO_MODER_MODER7_1;			// 00: Input (reset state)	01: General purpose output mode	10: Alternate function mode	11: Analog mode
	GPIOF->OSPEEDR |= GPIO_OSPEEDER_OSPEEDR7;		// V High  - 00: Low speed; 01: Medium speed; 10: High speed; 11: Very high speed
	GPIOF->AFR[0] |= 0b0101 << 28;					// 0b0101 = Alternate Function 5 (SPI5); 28 is position of Pin 7

	GPIOF->MODER |= GPIO_MODER_MODER8_1;			// 00: Input (reset state)	01: General purpose output mode	10: Alternate function mode	11: Analog mode
	GPIOF->OSPEEDR |= GPIO_OSPEEDER_OSPEEDR8;		// V High  - 00: Low speed; 01: Medium speed; 10: High speed; 11: Very high speed
	GPIOF->AFR[1] |= 0b0101 << 0;					// 0b0101 = Alternate Function 5 (SPI5); 0 is position of Pin 8

	GPIOF->MODER |= GPIO_MODER_MODER9_1;			// 00: Input (reset state)	01: General purpose output mode	10: Alternate function mode	11: Analog mode
	GPIOF->OSPEEDR |= GPIO_OSPEEDER_OSPEEDR9;		// V High  - 00: Low speed; 01: Medium speed; 10: High speed; 11: Very high speed
	GPIOF->AFR[1] |= 0b0101 << 4;					// 0b0101 = Alternate Function 5 (SPI5); 4 is position of Pin 9

	// Configure SPI
	SPI5->CR1 |= SPI_CR1_SSM;						// Software slave management: When SSM bit is set, NSS pin input is replaced with the value from the SSI bit
	SPI5->CR1 |= SPI_CR1_SSI;						// Internal slave select
	SPI5->CR1 |= SPI_CR1_BR_2;						// Baud rate control prescaler: 0b100: fPCLK/32
	SPI5->CR1 |= SPI_CR1_MSTR;						// Master selection

	SPI5->CR1 |= SPI_CR1_SPE;						// Enable SPI

	// Configure DMA
	RCC->AHB1ENR |= RCC_AHB1ENR_DMA2EN;

	/*TM_SPI_DMA_INT_t SPI5_DMA_INT = {SPI5_DMA_TX_CHANNEL , SPI5_DMA_TX_STREAM, SPI5_DMA_RX_CHANNEL, SPI5_DMA_RX_STREAM};
	 SPI5 TX and RX default settings
	#ifndef SPI5_DMA_TX_STREAM
	#define SPI5_DMA_TX_STREAM    DMA2_Stream6
	#define SPI5_DMA_TX_CHANNEL   DMA_Channel_7
	#endif
	#ifndef SPI5_DMA_RX_STREAM
	#define SPI5_DMA_RX_STREAM    DMA2_Stream5
	#define SPI5_DMA_RX_CHANNEL   DMA_Channel_7
	#endif
*/

}
